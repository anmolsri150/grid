module.exports = {
  transpileDependencies: true
}
